package com.example.nammakelsa.model

data class Worker(
    val id: String = "",
    val name: String = "",
    val skill: String = "",
    val phone: String = "",
    val ratePerDay: String = "",
    val profileImageUrl: String = "",
    val isAvailable: Boolean = true,
    val rating: Float = 0f,
    val totalRatings: Int = 0,
    val location: String = "",
    val description: String = ""
) {
    // Needed for Firestore deserialization
    constructor() : this("", "", "", "", "", "", true, 0f, 0, "", "")
}
