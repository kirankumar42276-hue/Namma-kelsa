package com.example.nammakelsa.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Brand Colors - Vibrant Indian-inspired palette
val OrangePrimary = Color(0xFFFF6B35)
val OrangeLight = Color(0xFFFF8A65)
val OrangeDark = Color(0xFFE64A19)
val GreenAccent = Color(0xFF4CAF50)
val RedAccent = Color(0xFFF44336)
val BlueSecondary = Color(0xFF1565C0)
val BackgroundLight = Color(0xFFF8F5F2)
val SurfaceLight = Color(0xFFFFFFFF)
val CardLight = Color(0xFFFFF3E0)

private val LightColorScheme = lightColorScheme(
    primary = OrangePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE0B2),
    onPrimaryContainer = Color(0xFF8B2500),
    secondary = BlueSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1E4FF),
    onSecondaryContainer = Color(0xFF001D36),
    background = BackgroundLight,
    onBackground = Color(0xFF1C1B1F),
    surface = SurfaceLight,
    onSurface = Color(0xFF1C1B1F),
    surfaceVariant = Color(0xFFF5DEB3),
    error = RedAccent,
    tertiary = GreenAccent
)

private val DarkColorScheme = darkColorScheme(
    primary = OrangeLight,
    onPrimary = Color(0xFF5C1900),
    primaryContainer = OrangeDark,
    onPrimaryContainer = Color(0xFFFFDBCB),
    secondary = Color(0xFF9ECAFF),
    onSecondary = Color(0xFF003258),
    background = Color(0xFF1C1B1F),
    onBackground = Color(0xFFE6E1E5),
    surface = Color(0xFF1C1B1F),
    onSurface = Color(0xFFE6E1E5),
    error = Color(0xFFFFB4AB),
    tertiary = Color(0xFF81C784)
)

@Composable
fun NammaKelsaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}
