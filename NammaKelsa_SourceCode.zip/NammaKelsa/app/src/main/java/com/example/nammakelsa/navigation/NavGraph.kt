package com.example.nammakelsa.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.nammakelsa.screens.AddWorkerScreen
import com.example.nammakelsa.screens.HomeScreen
import com.example.nammakelsa.screens.ProfileScreen
import com.example.nammakelsa.screens.WorkerDetailScreen
import com.example.nammakelsa.viewmodel.WorkerViewModel

@Composable
fun NavGraph(navController: NavHostController, viewModel: WorkerViewModel) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {

        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = viewModel,
                onWorkerClick = { workerId ->
                    navController.navigate(Screen.WorkerDetail.createRoute(workerId))
                }
            )
        }

        composable(Screen.AddWorker.route) {
            AddWorkerScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Profile.route) {
            ProfileScreen()
        }

        composable(
            route = Screen.WorkerDetail.route,
            arguments = listOf(navArgument("workerId") { type = NavType.StringType })
        ) { backStackEntry ->
            val workerId = backStackEntry.arguments?.getString("workerId") ?: return@composable
            WorkerDetailScreen(
                workerId = workerId,
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
