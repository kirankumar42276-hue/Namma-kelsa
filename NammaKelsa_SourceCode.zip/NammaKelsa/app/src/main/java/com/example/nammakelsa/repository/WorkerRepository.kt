package com.example.nammakelsa.repository

import android.net.Uri
import com.example.nammakelsa.model.Worker
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class WorkerRepository {

    private val db = FirebaseFirestore.getInstance()
    private val storage = FirebaseStorage.getInstance()
    private val workersCollection = db.collection("workers")

    // Real-time workers list
    fun getWorkers(): Flow<List<Worker>> = callbackFlow {
        val listener = workersCollection
            .orderBy("name", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val workers = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(Worker::class.java)?.copy(id = doc.id)
                } ?: emptyList()
                trySend(workers)
            }
        awaitClose { listener.remove() }
    }

    // Add worker
    suspend fun addWorker(worker: Worker, imageUri: Uri?): Result<String> {
        return try {
            val docRef = workersCollection.document()
            var imageUrl = ""

            if (imageUri != null) {
                val storageRef = storage.reference
                    .child("profile_images/${docRef.id}.jpg")
                storageRef.putFile(imageUri).await()
                imageUrl = storageRef.downloadUrl.await().toString()
            }

            val workerWithId = worker.copy(id = docRef.id, profileImageUrl = imageUrl)
            docRef.set(workerWithId).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Update worker availability
    suspend fun updateAvailability(workerId: String, isAvailable: Boolean): Result<Unit> {
        return try {
            workersCollection.document(workerId)
                .update("available", isAvailable).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Delete worker
    suspend fun deleteWorker(workerId: String): Result<Unit> {
        return try {
            workersCollection.document(workerId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Rate a worker
    suspend fun rateWorker(workerId: String, newRating: Float, currentWorker: Worker): Result<Unit> {
        return try {
            val totalRatings = currentWorker.totalRatings + 1
            val avgRating = ((currentWorker.rating * currentWorker.totalRatings) + newRating) / totalRatings
            workersCollection.document(workerId).update(
                mapOf(
                    "rating" to avgRating,
                    "totalRatings" to totalRatings
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
