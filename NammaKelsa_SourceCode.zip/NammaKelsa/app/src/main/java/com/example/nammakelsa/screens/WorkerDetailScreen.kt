package com.example.nammakelsa.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.nammakelsa.ui.theme.GreenAccent
import com.example.nammakelsa.ui.theme.RedAccent
import com.example.nammakelsa.viewmodel.WorkerViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkerDetailScreen(
    workerId: String,
    viewModel: WorkerViewModel,
    onNavigateBack: () -> Unit
) {
    val workers by viewModel.uiState.collectAsStateWithLifecycle()
    val worker = workers.workers.find { it.id == workerId } ?: return
    val context = LocalContext.current
    var showRatingDialog by remember { mutableStateOf(false) }
    var selectedRating by remember { mutableStateOf(0f) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(worker.name, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Profile Image Large
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                if (worker.profileImageUrl.isNotEmpty()) {
                    AsyncImage(
                        model = worker.profileImageUrl,
                        contentDescription = worker.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text(
                        text = worker.name.firstOrNull()?.toString() ?: "?",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(worker.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(worker.skill, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)

            Spacer(modifier = Modifier.height(8.dp))

            // Availability Badge
            Box(
                modifier = Modifier
                    .background(
                        if (worker.isAvailable) GreenAccent.copy(alpha = 0.15f) else RedAccent.copy(alpha = 0.15f),
                        RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (worker.isAvailable) "✅ Available for Work" else "🔴 Currently Busy",
                    color = if (worker.isAvailable) GreenAccent else RedAccent,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Availability Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Change Availability", fontWeight = FontWeight.Medium)
                Switch(
                    checked = worker.isAvailable,
                    onCheckedChange = { viewModel.updateAvailability(worker.id, it) }
                )
            }

            Divider(modifier = Modifier.padding(vertical = 12.dp))

            // Info Cards
            InfoRow(icon = Icons.Default.Phone, label = "Phone", value = worker.phone)
            if (worker.ratePerDay.isNotEmpty())
                InfoRow(icon = Icons.Default.CurrencyRupee, label = "Daily Rate", value = "₹${worker.ratePerDay}")
            if (worker.location.isNotEmpty())
                InfoRow(icon = Icons.Default.LocationOn, label = "Location", value = worker.location)
            if (worker.description.isNotEmpty())
                InfoRow(icon = Icons.Default.Info, label = "About", value = worker.description)
            if (worker.rating > 0f)
                InfoRow(icon = Icons.Default.Star, label = "Rating", value = "%.1f ⭐ (${worker.totalRatings} reviews)".format(worker.rating))

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Call Button
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${worker.phone}"))
                        context.startActivity(intent)
                    },
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenAccent)
                ) {
                    Icon(Icons.Default.Call, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Call", fontWeight = FontWeight.Bold)
                }

                // WhatsApp Button
                Button(
                    onClick = {
                        val url = "https://wa.me/91${worker.phone}"
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    },
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                ) {
                    Icon(Icons.Default.Message, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("WhatsApp", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Rate Button
            OutlinedButton(
                onClick = { showRatingDialog = true },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Star, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Rate this Worker", fontWeight = FontWeight.Bold)
            }
        }
    }

    // Rating Dialog
    if (showRatingDialog) {
        AlertDialog(
            onDismissRequest = { showRatingDialog = false },
            title = { Text("Rate ${worker.name}") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("How was the work quality?")
                    Spacer(Modifier.height(16.dp))
                    Row {
                        (1..5).forEach { star ->
                            IconButton(onClick = { selectedRating = star.toFloat() }) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "$star stars",
                                    tint = if (star <= selectedRating) Color(0xFFFFC107) else Color.Gray,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (selectedRating > 0) {
                        viewModel.rateWorker(worker.id, selectedRating, worker)
                        showRatingDialog = false
                    }
                }) { Text("Submit") }
            },
            dismissButton = { TextButton(onClick = { showRatingDialog = false }) { Text("Cancel") } }
        )
    }

    // Delete Confirmation Dialog
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete Worker") },
            text = { Text("Are you sure you want to remove ${worker.name} from the list?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteWorker(worker.id)
                        showDeleteDialog = false
                        onNavigateBack()
                    }
                ) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(label, style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        }
    }
}
