package com.example.nammakelsa.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.nammakelsa.model.Worker
import com.example.nammakelsa.repository.WorkerRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class WorkerUiState(
    val workers: List<Worker> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val searchQuery: String = "",
    val filterAvailable: Boolean? = null // null = show all
)

class WorkerViewModel : ViewModel() {

    private val repository = WorkerRepository()

    private val _uiState = MutableStateFlow(WorkerUiState(isLoading = true))
    val uiState: StateFlow<WorkerUiState> = _uiState.asStateFlow()

    // Filtered workers based on search + filter
    val filteredWorkers: StateFlow<List<Worker>> = _uiState
        .map { state ->
            state.workers
                .filter { worker ->
                    val matchesSearch = state.searchQuery.isEmpty() ||
                        worker.name.contains(state.searchQuery, ignoreCase = true) ||
                        worker.skill.contains(state.searchQuery, ignoreCase = true) ||
                        worker.location.contains(state.searchQuery, ignoreCase = true)
                    val matchesFilter = state.filterAvailable == null ||
                        worker.isAvailable == state.filterAvailable
                    matchesSearch && matchesFilter
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        loadWorkers()
    }

    private fun loadWorkers() {
        viewModelScope.launch {
            repository.getWorkers()
                .catch { e ->
                    _uiState.update { it.copy(isLoading = false, errorMessage = e.message) }
                }
                .collect { workers ->
                    _uiState.update { it.copy(workers = workers, isLoading = false) }
                }
        }
    }

    fun addWorker(worker: Worker, imageUri: Uri?) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val result = repository.addWorker(worker, imageUri)
            _uiState.update {
                it.copy(
                    isLoading = false,
                    successMessage = if (result.isSuccess) "Worker added successfully!" else null,
                    errorMessage = if (result.isFailure) result.exceptionOrNull()?.message else null
                )
            }
        }
    }

    fun deleteWorker(workerId: String) {
        viewModelScope.launch {
            repository.deleteWorker(workerId)
        }
    }

    fun updateAvailability(workerId: String, isAvailable: Boolean) {
        viewModelScope.launch {
            repository.updateAvailability(workerId, isAvailable)
        }
    }

    fun rateWorker(workerId: String, rating: Float, worker: Worker) {
        viewModelScope.launch {
            repository.rateWorker(workerId, rating, worker)
        }
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun onFilterChange(available: Boolean?) {
        _uiState.update { it.copy(filterAvailable = available) }
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, successMessage = null) }
    }
}
