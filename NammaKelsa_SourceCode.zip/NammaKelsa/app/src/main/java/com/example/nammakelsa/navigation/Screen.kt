package com.example.nammakelsa.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector? = null) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object AddWorker : Screen("add_worker", "Add Worker", Icons.Default.AddCircle)
    object Profile : Screen("profile", "Profile", Icons.Default.Person)
    object WorkerDetail : Screen("worker_detail/{workerId}", "Worker Detail") {
        fun createRoute(workerId: String) = "worker_detail/$workerId"
    }
}

val bottomNavItems = listOf(Screen.Home, Screen.AddWorker, Screen.Profile)
